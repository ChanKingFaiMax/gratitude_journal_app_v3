# App Store 截图素材说明

## 5张核心功能截图

| 序号 | 文件名 | 功能页面 | 建议标题文案 |
|------|--------|----------|-------------|
| 1 | screenshot_1_home.webp | 首页-感恩题目卡片 | 每日感恩，滑动选择题目 |
| 2 | screenshot_2_history.webp | 历史-统计+日记列表 | 记录成长，回顾感恩时刻 |
| 3 | screenshot_3_detail.webp | 日记详情+智者评论 | 智者启示，获得心灵洞见 |
| 4 | screenshot_4_settings.webp | 设置-统计+成就 | 成就系统，见证你的坚持 |
| 5 | screenshot_5_review.webp | 洞察报告-能量图谱 | 意识能量图谱，了解内心 |

## App Store 6.5寸尺寸要求
- 尺寸：1290 x 2796 像素
- 格式：PNG 或 JPEG
